#!/bin/sh

/bin/dt -t"Update installed."
echo ""
echo "#######################"
echo "#  Update installed.  #"
echo "#######################"
echo ""
/bin/sync

rm -f /var/tuxbox/plugins/coolithek/json.lua
rm -f /var/tuxbox/plugins/coolithek/local.lua

/bin/sync
sleep 2
