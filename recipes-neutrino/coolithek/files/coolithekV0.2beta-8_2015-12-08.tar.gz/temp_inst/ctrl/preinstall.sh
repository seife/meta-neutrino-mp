#!/bin/sh

echo ""
echo "#########################"
echo "#  start plugin update  #"
echo "#########################"
echo ""
/bin/dt -t"start plugin update"
